# PMM Academy Skills Library

A collection of 8 Claude Skills for Product Marketing Managers. Each skill is a self-contained workflow that helps you execute one high-leverage GTM task with Claude.

## What's included

1. **ICP Builder** — Turn customer research into a structured Ideal Customer Profile
2. **Persona Generator** — Synthesize interviews into actionable B2B personas
3. **Messaging House** — Build a complete messaging architecture (promise + pillars + proof)
4. **Battlecard Builder** — Create segment-specific competitive battlecards
5. **Launch Brief** — Write a cross-functional one-page launch brief
6. **Sales Deck** — Draft a 10-slide pitch following proven narrative structure
7. **Win/Loss Interview** — Run structured post-deal analysis programs
8. **GTM Motion Diagnostic** — Evaluate PLG vs. SLG vs. Hybrid vs. Partner-Led fit

## How to install

### In Claude.ai (web or desktop app)

1. Go to your Claude Projects
2. Create a new Project (or open an existing one)
3. Upload the SKILL.md file from any skill folder above into the project's knowledge
4. The skill will trigger automatically when you describe a relevant task in that project

### In Claude Code

1. Place the skill folder in `~/.claude/skills/` (or the project's `.claude/skills/` for project-specific use)
2. The skill will trigger automatically when relevant

### As individual prompts

If you don't want to install as a skill, you can simply copy the body of any SKILL.md file and paste it into a Claude conversation as a system prompt or context, then describe your task.

## How to use

Each skill triggers when you describe a relevant task. Examples:

- "Build an ICP for my product" → triggers ICP Builder
- "I have 8 customer interviews, help me synthesize them into a persona" → triggers Persona Generator
- "Write a launch brief for our Q3 release" → triggers Launch Brief
- "We keep losing deals to Competitor X, build me a battlecard" → triggers Battlecard Builder

Be specific about your context. The more inputs you provide (real customer quotes, real deal data, real positioning), the better the output.

## Built by PMM Academy

These skills are part of the GTM Mastery curriculum. They encode the workflows used by category-defining product marketing teams.
